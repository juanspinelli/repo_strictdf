Strictdf
********

Library with functions to determine data types by columns and clean the dataframe
=================================================================================

.. image:: https://img.shields.io/badge/Version-V%200.1.0-important?style=for-the-badge
    :target: https://pypi.org/project/strictdf/

.. image:: https://img.shields.io/badge/Level-TechInterview-green?style=for-the-badge
    :target: https://pypi.org/project/strictdf/

.. image:: https://img.shields.io/badge/Tools-Python%20%2F%20Pandas%20%2F%20Jupyter%20%2F%20Pytest-yellow?style=for-the-badge
    :target: https://pypi.org/project/strictdf/

.. image:: https://img.shields.io/badge/Type%20of%20exercise-Practical-sucess?style=for-the-badge
    :target: https://pypi.org/project/strictdf/

Strictdf is a simple dataframe check
------------------------------------